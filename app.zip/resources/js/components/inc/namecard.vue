<template lang="">
    <div class="text-xl text-sky-700 font-bold mb-2">
        <slot></slot>
    </div>
</template>
