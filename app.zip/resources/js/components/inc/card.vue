<template lang="">
    <div class="p-6 bg-white border border-gray-200 rounded-md">
        <slot></slot>
    </div>
</template>
