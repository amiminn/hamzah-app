<template lang="">
    <Head>
        <slot></slot>
    </Head>
</template>
<script>
import { Head } from "@inertiajs/vue3";
export default {
    components: { Head },
};
</script>
