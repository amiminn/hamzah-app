<template lang="">
    <div class="text-md mb-2 text-sky-700 font-bold">
        <slot></slot>
    </div>
</template>
