<template lang="">
    <div>404 not found</div>
</template>
<script>
export default {};
</script>
<style lang=""></style>
