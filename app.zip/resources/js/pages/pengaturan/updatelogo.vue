<template lang="">
    <card>
        <namecard>logo app</namecard>
        <div class="flex justify-center">
            <img
                src="assets/main/resume.png"
                alt="avatar"
                class="w-40 border-2"
            />
        </div>
    </card>
</template>
<script>
export default {};
</script>
<style lang=""></style>
